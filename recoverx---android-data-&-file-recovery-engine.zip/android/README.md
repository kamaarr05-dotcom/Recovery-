# RecoverX - Production Android Data & File Recovery Engine

RecoverX adalah aplikasi pemulihan data Android sejati yang dibangun menggunakan **Kotlin**, **Jetpack Compose**, **Material 3**, dan **AndroidX Coroutines**.

Aplikasi ini mengimplementasikan algoritma pemulihan data nyata:
1. **MediaStore Trash API (Android 11+ / API 30+)**: Membaca file gambar, video, dan dokumen yang ditandai dalam recycle bin sistem (`IS_TRASHED=1`, `QUERY_ARG_MATCH_TRASHED=MATCH_ONLY`).
2. **LOST.DIR Reconstruction**: Membaca cluster tak berekstensi yang diselamatkan oleh filesystem check Android (fsck) setelah crash / mati mendadak, mengidentifikasi header binary sesungguhnya, dan mengembalikannya ke format asli.
3. **Hidden System & App Cache Scanner**: Memindai direktori tersembunyi (`.trash`, `.trashed`, `.thumbnails`, `.nomedia`, database sent WhatsApp/Telegram) untuk menemukan file full-resolution yang terhapus dari galeri biasa.
4. **Binary File Signature Carving Engine**: Menganalisis magic bytes (JPEG SOI/EOI, PNG magic+IEND chunk, MP4/MOV ftyp box, PDF %PDF-/%%EOF, ZIP/APK/DOCX/XLSX PK headers) untuk memulihkan file dari aliran biner storage.
5. **Storage Access Framework (SAF) & Scoped Storage Compliant**: Menjamin pemulihan aman tanpa merusak data sumber, menulis file baru ke folder tujuan pengguna (`DocumentFile`), dan mendaftarkan media yang pulih kembali ke `MediaStore` agar langsung muncul di Galeri foto / Google Photos.

---

## 🛠️ Cara Membangun Project (Build APK)

### 1. Menggunakan Android Studio (Rekomendasi)
1. Buka **Android Studio Iguana / Jellyfish / Ladybug (2024+)**.
2. Pilih **Open Project** lalu arahkan ke folder `/android` di repositori ini.
3. Tunggu Gradle Sync selesai.
4. Pilih target perangkat fisik Android atau Emulator (Android 10 - Android 14+).
5. Klik **Run 'app'** (Shift + F10) atau pilih menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

### 2. Menggunakan Command Line (Terminal / CMD)
```bash
cd android
chmod +x gradlew
./gradlew assembleDebug
```
File APK yang dihasilkan akan berada di:
`android/app/build/outputs/apk/debug/app-debug.apk`

---

## 🔐 Izin & Keamanan Android
- **Android 13+ (API 33+)**: Menggunakan `READ_MEDIA_IMAGES`, `READ_MEDIA_VIDEO`, `READ_MEDIA_AUDIO`.
- **Android 11+ (API 30+)**: Menggunakan `MANAGE_EXTERNAL_STORAGE` untuk akses mendalam ke seluruh direktori storage dan LOST.DIR tanpa memerlukan Root.
- **Deteksi Root**: Aplikasi mendeteksi status root secara transparan tanpa menjadikannya prasyarat wajib. Jika perangkat tidak di-root, RecoverX tetap beroperasi dengan seluruh kemampuan Scoped Storage dan All Files Access.
