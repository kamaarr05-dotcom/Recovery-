package com.recoverx.app

import android.Manifest
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.DocumentsContract
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.recoverx.app.data.security.StoragePermissionHelper
import com.recoverx.app.ui.screens.*
import com.recoverx.app.ui.theme.DarkBackground
import com.recoverx.app.ui.theme.RecoverXTheme
import com.recoverx.app.ui.viewmodel.RecoveryViewModel
import com.recoverx.app.ui.viewmodel.ScreenState

class MainActivity : ComponentActivity() {

    private val viewModel: RecoveryViewModel by viewModels()
    private val permissionHelper by lazy { StoragePermissionHelper(this) }

    // SAF directory picker launcher
    private val openDocumentTreeLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocumentTree()
    ) { treeUri: Uri? ->
        if (treeUri != null) {
            val takeFlags = Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            contentResolver.takePersistableUriPermission(treeUri, takeFlags)
            viewModel.executeRecovery(treeUri)
        }
    }

    // Android 11+ All Files Access launcher
    private val manageAllFilesLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
        viewModel.refreshPermissions()
    }

    // Media & Storage permissions launcher
    private val requestPermissionsLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) {
        viewModel.refreshPermissions()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            RecoverXTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkBackground
                ) {
                    val state by viewModel.uiState.collectAsState()

                    when (val screen = state.currentScreen) {
                        is ScreenState.Home -> {
                            HomeScreen(
                                state = state,
                                onStartScan = { viewModel.startScan() },
                                onSelectMode = { viewModel.setScanMode(it) },
                                onRequestPermission = { requestRequiredPermissions() }
                            )
                        }

                        is ScreenState.Scanning -> {
                            ScanningScreen(
                                state = state,
                                onCancelScan = { viewModel.cancelScan() }
                            )
                        }

                        is ScreenState.FoundFiles -> {
                            FoundFilesScreen(
                                state = state,
                                onBackToHome = { viewModel.backToHome() },
                                onSelectCategory = { viewModel.selectCategory(it) },
                                onToggleSelectFile = { viewModel.toggleFileSelection(it) },
                                onToggleSelectAll = { viewModel.toggleSelectAll() },
                                onOpenFilePreview = { viewModel.openPreview(it) },
                                onStartRecovery = { viewModel.showDestinationDialog() },
                                onSearchChanged = { viewModel.setSearchQuery(it) }
                            )
                        }

                        is ScreenState.Preview -> {
                            PreviewScreen(
                                file = screen.file,
                                onBack = { viewModel.backToFoundFiles() },
                                onToggleSelect = { viewModel.toggleFileSelection(screen.file.id) },
                                onRecoverSingle = { viewModel.showDestinationDialog() }
                            )
                        }

                        is ScreenState.Recovering -> {
                            // Show recovering state or progress
                            ScanningScreen(
                                state = state.copy(
                                    scanProgress = state.scanProgress.copy(
                                        currentMethod = "Memulihkan: ${screen.currentFile}"
                                    )
                                ),
                                onCancelScan = {}
                            )
                        }

                        is ScreenState.Result -> {
                            RecoveryResultScreen(
                                summary = screen.summary,
                                onFinish = { viewModel.backToHome() },
                                onOpenFolder = { openDestinationFolder(screen.summary.destinationFolder) }
                            )
                        }
                    }

                    // Destination selector dialog
                    if (state.isTargetDestinationDialogVisible) {
                        RecoveryDestinationDialog(
                            selectedCount = state.selectedCount,
                            onDismiss = { viewModel.hideDestinationDialog() },
                            onConfirmDefaultLocation = { viewModel.executeRecovery(null) },
                            onChooseCustomFolder = {
                                openDocumentTreeLauncher.launch(null)
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        viewModel.refreshPermissions()
    }

    private fun requestRequiredPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val manageIntent = permissionHelper.createManageAllFilesIntent()
            if (manageIntent != null) {
                manageAllFilesLauncher.launch(manageIntent)
                return
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestPermissionsLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_AUDIO
                )
            )
        } else {
            requestPermissionsLauncher.launch(
                arrayOf(
                    Manifest.permission.READ_EXTERNAL_STORAGE,
                    Manifest.permission.WRITE_EXTERNAL_STORAGE
                )
            )
        }
    }

    private fun openDestinationFolder(folderPath: String) {
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(Uri.parse(folderPath), DocumentsContract.Document.MIME_TYPE_DIR)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_GRANT_READ_URI_PERMISSION
            }
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Tersimpan di: $folderPath", Toast.LENGTH_LONG).show()
        }
    }
}
