package com.recoverx.app.data.carving

import com.recoverx.app.data.model.RecoveryConfidence
import com.recoverx.app.data.model.ScanCategory
import java.io.File
import java.io.InputStream
import java.io.RandomAccessFile

data class CarvedResult(
    val offset: Long,
    val length: Long,
    val extension: String,
    val mimeType: String,
    val category: ScanCategory,
    val confidence: RecoveryConfidence,
    val signatureName: String,
    val hexHeader: String
)

/**
 * Real binary byte-signature carving engine for Android storage.
 * Performs sequential and block-level inspection of magic byte headers and trailers.
 */
class FileSignatureEngine {

    companion object {
        // JPEG: Start Of Image (SOI) = FF D8 FF, End Of Image (EOI) = FF D9
        private val JPEG_SOI = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte())
        private val JPEG_EOI = byteArrayOf(0xFF.toByte(), 0xD9.toByte())

        // PNG: 89 50 4E 47 0D 0A 1A 0A
        private val PNG_HEADER = byteArrayOf(
            0x89.toByte(), 0x50.toByte(), 0x4E.toByte(), 0x47.toByte(),
            0x0D.toByte(), 0x0A.toByte(), 0x1A.toByte(), 0x0A.toByte()
        )
        // PNG IEND chunk
        private val PNG_IEND = byteArrayOf(0x49.toByte(), 0x45.toByte(), 0x4E.toByte(), 0x44.toByte())

        // GIF: GIF87a or GIF89a
        private val GIF_HEADER = "GIF8".toByteArray(Charsets.US_ASCII)

        // PDF: %PDF-
        private val PDF_HEADER = byteArrayOf(0x25.toByte(), 0x50.toByte(), 0x44.toByte(), 0x46.toByte(), 0x2D.toByte())
        private val PDF_EOF = byteArrayOf(0x25.toByte(), 0x25.toByte(), 0x45.toByte(), 0x4F.toByte(), 0x46.toByte())

        // ZIP / APK / Office XML: PK\x03\x04
        private val ZIP_LOCAL_HEADER = byteArrayOf(0x50.toByte(), 0x4B.toByte(), 0x03.toByte(), 0x04.toByte())
        private val ZIP_EOCD = byteArrayOf(0x50.toByte(), 0x4B.toByte(), 0x05.toByte(), 0x06.toByte())

        // RAR: Rar!\x1A\x07
        private val RAR_HEADER = byteArrayOf(0x52.toByte(), 0x61.toByte(), 0x72.toByte(), 0x21.toByte(), 0x1A.toByte(), 0x07.toByte())

        // MP3 ID3v2: "ID3"
        private val MP3_ID3 = byteArrayOf(0x49.toByte(), 0x44.toByte(), 0x33.toByte())

        // RIFF (WAV, WebP, AVI)
        private val RIFF_HEADER = byteArrayOf(0x52.toByte(), 0x49.toByte(), 0x46.toByte(), 0x46.toByte())

        // OGG
        private val OGG_HEADER = byteArrayOf(0x4F.toByte(), 0x67.toByte(), 0x67.toByte(), 0x53.toByte())
    }

    /**
     * Inspect a byte array buffer (e.g. from an unindexed block or lost file)
     * and carve out valid media streams with exact length parsing.
     */
    fun identifySignature(bytes: ByteArray, offsetInBytes: Long = 0L): CarvedResult? {
        if (bytes.size < 16) return null

        // 1. JPEG Check
        if (bytes[0] == 0xFF.toByte() && bytes[1] == 0xD8.toByte() && bytes[2] == 0xFF.toByte()) {
            val length = findJpegLength(bytes)
            val hex = bytes.take(16).joinToString(" ") { "%02X".format(it) }
            return CarvedResult(
                offset = offsetInBytes,
                length = length,
                extension = "jpg",
                mimeType = "image/jpeg",
                category = ScanCategory.PHOTOS,
                confidence = if (length > 1024) RecoveryConfidence.HIGH else RecoveryConfidence.MEDIUM,
                signatureName = "JPEG / JFIF / EXIF",
                hexHeader = hex
            )
        }

        // 2. PNG Check
        if (matches(bytes, 0, PNG_HEADER)) {
            val length = findPngLength(bytes)
            val hex = bytes.take(16).joinToString(" ") { "%02X".format(it) }
            return CarvedResult(
                offset = offsetInBytes,
                length = length,
                extension = "png",
                mimeType = "image/png",
                category = ScanCategory.PHOTOS,
                confidence = RecoveryConfidence.HIGH,
                signatureName = "Portable Network Graphics (PNG)",
                hexHeader = hex
            )
        }

        // 3. MP4 / MOV / 3GP Check (ftyp atom at byte 4)
        if (bytes.size >= 12 && bytes[4] == 'f'.code.toByte() && bytes[5] == 't'.code.toByte() &&
            bytes[6] == 'y'.code.toByte() && bytes[7] == 'p'.code.toByte()
        ) {
            val ftypBoxSize = ((bytes[0].toLong() and 0xFF) shl 24) or
                    ((bytes[1].toLong() and 0xFF) shl 16) or
                    ((bytes[2].toLong() and 0xFF) shl 8) or
                    (bytes[3].toLong() and 0xFF)
            val brand = String(bytes, 8, 4, Charsets.US_ASCII)
            val ext = if (brand.startsWith("3g")) "3gp" else if (brand == "qt  ") "mov" else "mp4"
            val mime = if (ext == "3gp") "video/3gpp" else if (ext == "mov") "video/quicktime" else "video/mp4"
            val hex = bytes.take(16).joinToString(" ") { "%02X".format(it) }

            return CarvedResult(
                offset = offsetInBytes,
                length = bytes.size.toLong().coerceAtLeast(ftypBoxSize),
                extension = ext,
                mimeType = mime,
                category = ScanCategory.VIDEOS,
                confidence = RecoveryConfidence.HIGH,
                signatureName = "ISO Base Media File ($brand)",
                hexHeader = hex
            )
        }

        // 4. PDF Check
        if (matches(bytes, 0, PDF_HEADER)) {
            val length = findPdfLength(bytes)
            val hex = bytes.take(16).joinToString(" ") { "%02X".format(it) }
            return CarvedResult(
                offset = offsetInBytes,
                length = length,
                extension = "pdf",
                mimeType = "application/pdf",
                category = ScanCategory.DOCUMENTS,
                confidence = RecoveryConfidence.HIGH,
                signatureName = "Adobe Portable Document Format (PDF)",
                hexHeader = hex
            )
        }

        // 5. ZIP / DOCX / XLSX / APK Check (PK\x03\x04)
        if (matches(bytes, 0, ZIP_LOCAL_HEADER)) {
            val (ext, mime, cat, name) = identifyZipSubtype(bytes)
            val length = findZipLength(bytes)
            val hex = bytes.take(16).joinToString(" ") { "%02X".format(it) }
            return CarvedResult(
                offset = offsetInBytes,
                length = length,
                extension = ext,
                mimeType = mime,
                category = cat,
                confidence = RecoveryConfidence.HIGH,
                signatureName = name,
                hexHeader = hex
            )
        }

        // 6. WebP / WAV Check (RIFF header)
        if (matches(bytes, 0, RIFF_HEADER) && bytes.size >= 12) {
            val riffType = String(bytes, 8, 4, Charsets.US_ASCII)
            val hex = bytes.take(16).joinToString(" ") { "%02X".format(it) }
            val riffSize = ((bytes[4].toLong() and 0xFF)) or
                    ((bytes[5].toLong() and 0xFF) shl 8) or
                    ((bytes[6].toLong() and 0xFF) shl 16) or
                    ((bytes[7].toLong() and 0xFF) shl 24) + 8L

            when (riffType) {
                "WEBP" -> return CarvedResult(
                    offset = offsetInBytes,
                    length = riffSize.coerceAtMost(bytes.size.toLong()),
                    extension = "webp",
                    mimeType = "image/webp",
                    category = ScanCategory.PHOTOS,
                    confidence = RecoveryConfidence.HIGH,
                    signatureName = "WebP Image",
                    hexHeader = hex
                )
                "WAVE" -> return CarvedResult(
                    offset = offsetInBytes,
                    length = riffSize.coerceAtMost(bytes.size.toLong()),
                    extension = "wav",
                    mimeType = "audio/wav",
                    category = ScanCategory.AUDIO,
                    confidence = RecoveryConfidence.HIGH,
                    signatureName = "WAV Audio Stream",
                    hexHeader = hex
                )
            }
        }

        // 7. MP3 Check (ID3v2)
        if (matches(bytes, 0, MP3_ID3) && bytes.size >= 10) {
            // ID3 synchsafe size
            val tagSize = ((bytes[6].toInt() and 0x7F) shl 21) or
                    ((bytes[7].toInt() and 0x7F) shl 14) or
                    ((bytes[8].toInt() and 0x7F) shl 7) or
                    (bytes[9].toInt() and 0x7F)
            val hex = bytes.take(16).joinToString(" ") { "%02X".format(it) }
            return CarvedResult(
                offset = offsetInBytes,
                length = bytes.size.toLong(),
                extension = "mp3",
                mimeType = "audio/mpeg",
                category = ScanCategory.AUDIO,
                confidence = RecoveryConfidence.HIGH,
                signatureName = "MPEG Audio (ID3v2)",
                hexHeader = hex
            )
        }

        // 8. OGG Check
        if (matches(bytes, 0, OGG_HEADER)) {
            val hex = bytes.take(16).joinToString(" ") { "%02X".format(it) }
            return CarvedResult(
                offset = offsetInBytes,
                length = bytes.size.toLong(),
                extension = "ogg",
                mimeType = "audio/ogg",
                category = ScanCategory.AUDIO,
                confidence = RecoveryConfidence.MEDIUM,
                signatureName = "Ogg Vorbis / Opus Stream",
                hexHeader = hex
            )
        }

        return null
    }

    private fun matches(buffer: ByteArray, startOffset: Int, target: ByteArray): Boolean {
        if (buffer.size - startOffset < target.size) return false
        for (i in target.indices) {
            if (buffer[startOffset + i] != target[i]) return false
        }
        return true
    }

    private fun findJpegLength(bytes: ByteArray): Long {
        // Search backwards or forwards for FF D9 (EOI)
        var lastEoi = -1
        for (i in 2 until bytes.size - 1) {
            if (bytes[i] == 0xFF.toByte() && bytes[i + 1] == 0xD9.toByte()) {
                lastEoi = i + 2
            }
        }
        return if (lastEoi > 0) lastEoi.toLong() else bytes.size.toLong()
    }

    private fun findPngLength(bytes: ByteArray): Long {
        for (i in 8 until bytes.size - 8) {
            if (matches(bytes, i, PNG_IEND)) {
                // IEND chunk has 4 bytes length, 4 bytes chunk name, 0 data, 4 bytes CRC
                return (i + 4 + 4).toLong().coerceAtMost(bytes.size.toLong())
            }
        }
        return bytes.size.toLong()
    }

    private fun findPdfLength(bytes: ByteArray): Long {
        for (i in bytes.size - 6 downTo 10) {
            if (matches(bytes, i, PDF_EOF)) {
                return (i + 5).toLong()
            }
        }
        return bytes.size.toLong()
    }

    private fun findZipLength(bytes: ByteArray): Long {
        // Search for End of Central Directory Record (PK\x05\x06)
        for (i in bytes.size - 22 downTo 0) {
            if (matches(bytes, i, ZIP_EOCD)) {
                // EOCD record is at least 22 bytes long plus comment length
                val commentLen = if (i + 21 < bytes.size) {
                    ((bytes[i + 20].toInt() and 0xFF)) or ((bytes[i + 21].toInt() and 0xFF) shl 8)
                } else 0
                return (i + 22 + commentLen).toLong().coerceAtMost(bytes.size.toLong())
            }
        }
        return bytes.size.toLong()
    }

    private data class ZipSubtype(
        val ext: String,
        val mime: String,
        val category: ScanCategory,
        val name: String
    )

    private fun identifyZipSubtype(bytes: ByteArray): ZipSubtype {
        // Check for AndroidManifest.xml in ZIP header -> APK
        val sample = String(bytes, 0, bytes.size.coerceAtMost(4096), Charsets.ISO_8859_1)
        return when {
            sample.contains("AndroidManifest.xml") -> ZipSubtype("apk", "application/vnd.android.package-archive", ScanCategory.APKS, "Android Application Package (APK)")
            sample.contains("word/") -> ZipSubtype("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document", ScanCategory.DOCUMENTS, "Microsoft Word Document")
            sample.contains("xl/") -> ZipSubtype("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ScanCategory.DOCUMENTS, "Microsoft Excel Spreadsheet")
            sample.contains("ppt/") -> ZipSubtype("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation", ScanCategory.DOCUMENTS, "Microsoft PowerPoint")
            else -> ZipSubtype("zip", "application/zip", ScanCategory.ARCHIVES, "ZIP Archive")
        }
    }
}
