package com.recoverx.app.data.model

import android.net.Uri

enum class FileSource {
    MEDIASTORE_TRASH,       // Android 11+ MediaStore Trash (IS_TRASHED=1)
    LOST_DIR,               // Orphaned fsck clusters in LOST.DIR
    HIDDEN_CACHE,           // Intact full-res cached/deleted files (.thumbnails, .trashed)
    FILE_CARVING,           // Byte-signature carved files from raw storage streams
    APP_ORPHAN              // App private/public abandoned or sent caches
}

enum class RecoveryConfidence {
    HIGH,                   // Header and trailer verified, checksum consistent
    MEDIUM,                 // Header valid, structure intact, trailer estimated
    LOW                     // Partial header recovered or cluster fragmentation
}

data class RecoverableFile(
    val id: String,
    val name: String,
    val originalPath: String,
    val uri: Uri?,
    val category: ScanCategory,
    val mimeType: String,
    val extension: String,
    val sizeBytes: Long,
    val source: FileSource,
    val confidence: RecoveryConfidence,
    val headerOffset: Long = 0L,
    val length: Long = sizeBytes,
    val timestamp: Long = System.currentTimeMillis(),
    val isSelected: Boolean = false,
    val sha256Hex: String? = null,
    val isRecovered: Boolean = false,
    val restoredPath: String? = null,
    val hexSnippet: String? = null
)
