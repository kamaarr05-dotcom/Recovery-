package com.recoverx.app.data.model

data class ScanProgress(
    val isScanning: Boolean = false,
    val isPaused: Boolean = false,
    val isFinished: Boolean = false,
    val currentPath: String = "",
    val filesScannedCount: Long = 0L,
    val filesFoundCount: Long = 0L,
    val bytesProcessed: Long = 0L,
    val currentSector: Long = 0L,
    val categoryCounts: Map<ScanCategory, Int> = emptyMap(),
    val currentMethod: String = "",
    val elapsedTimeMs: Long = 0L,
    val errorMessage: String? = null
)

data class StorageVolumeInfo(
    val description: String,
    val path: String,
    val totalBytes: Long,
    val freeBytes: Long,
    val isRemovable: Boolean,
    val isEmulated: Boolean
)
