package com.recoverx.app.data.scanner

import android.content.Context
import android.os.Build
import android.os.Environment
import com.recoverx.app.data.carving.FileSignatureEngine
import com.recoverx.app.data.model.FileSource
import com.recoverx.app.data.model.RecoverableFile
import com.recoverx.app.data.model.RecoveryConfidence
import com.recoverx.app.data.model.ScanCategory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.isActive
import java.io.File
import java.io.FileInputStream
import java.util.UUID

class DeepStorageCarvingScanner(
    private val context: Context,
    private val signatureEngine: FileSignatureEngine
) {

    /**
     * Comprehensive real storage scanner that deeply searches:
     * 1. System & App Trash: .trash, .trashed, .Trash-1000, .pending-*
     * 2. Android Gallery Thumbnails & Micro-caches:
     *    - DCIM/.thumbnails (Full/mid resolution JPEG snapshots cached by camera)
     *    - DCIM/.trashed, Pictures/.trashed, Download/.trashed
     *    - Pictures/.thumbnails, Movies/.thumbnails
     * 3. Messaging hidden sent/received attachments & trash:
     *    - Android/media/com.whatsapp/WhatsApp/Media/.trash
     *    - Android/media/com.whatsapp/WhatsApp/Media/.Statuses
     *    - Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images/Sent
     *    - Android/media/org.telegram.messenger/cache
     * 4. System crash recovery sectors:
     *    - LOST.DIR (Orphan clusters from unexpected shutdown or unmount)
     * 5. Raw file signature verification on all unindexed/orphan binary files.
     */
    fun scanDeepStorage(
        onPathInspected: (String) -> Unit
    ): Flow<RecoverableFile> = flow {
        val storageRoot = Environment.getExternalStorageDirectory()
        val targets = mutableListOf<File>()

        // 1. Direct locations known to house deleted or cached image artifacts
        val candidateLocations = listOf(
            // Dedicated trash directories created by Scoped Storage & File Managers
            File(storageRoot, ".trash"),
            File(storageRoot, ".trashed"),
            File(storageRoot, ".Trash-1000"),
            File(storageRoot, "LOST.DIR"),
            File(storageRoot, "DCIM/.thumbnails"),
            File(storageRoot, "Pictures/.thumbnails"),
            File(storageRoot, "DCIM/.trashed"),
            File(storageRoot, "Pictures/.trashed"),
            File(storageRoot, "Download/.trash"),
            File(storageRoot, "Download/.trashed"),
            File(storageRoot, "Movies/.thumbnails"),
            
            // App-specific deleted caches & backup stores
            File(storageRoot, "Android/media/com.whatsapp/WhatsApp/Media/.trash"),
            File(storageRoot, "Android/media/com.whatsapp/WhatsApp/Media/.Statuses"),
            File(storageRoot, "Android/media/com.whatsapp/WhatsApp/Media/WhatsApp Images/Sent"),
            File(storageRoot, "Android/media/org.telegram.messenger/cache"),
            File(storageRoot, "Android/data/com.miui.gallery/cache"),
            File(storageRoot, "Android/data/com.sec.android.gallery3d/cache"),
            File(storageRoot, "Android/data/com.google.android.apps.photos/cache"),
            
            // System and app public caches
            context.cacheDir,
            context.externalCacheDir,
            File(storageRoot, "Android/data/${context.packageName}/cache")
        )

        for (loc in candidateLocations) {
            if (loc != null && loc.exists() && loc.canRead()) {
                targets.add(loc)
            }
        }

        // 2. Also deep-traverse DCIM, Pictures, and Download subfolders for .nomedia, .trashed, or hidden items
        val parentMediaFolders = listOf(
            File(storageRoot, "DCIM"),
            File(storageRoot, "Pictures"),
            File(storageRoot, "Download"),
            File(storageRoot, "Documents")
        )
        for (parent in parentMediaFolders) {
            if (parent.exists() && parent.canRead()) {
                targets.add(parent)
            }
        }

        // 3. Detect external SD Cards & OTG
        val extDirs = context.getExternalFilesDirs(null)
        for (f in extDirs) {
            val root = f?.parentFile?.parentFile?.parentFile?.parentFile
            if (root != null && root.exists() && root.canRead()) {
                val lostDir = File(root, "LOST.DIR")
                if (lostDir.exists() && lostDir.canRead()) targets.add(lostDir)
                val sdTrash = File(root, ".trash")
                if (sdTrash.exists() && sdTrash.canRead()) targets.add(sdTrash)
            }
        }

        val buffer = ByteArray(8192)
        val visitedPaths = HashSet<String>()

        for (target in targets) {
            if (!currentCoroutineContext().isActive) break
            onPathInspected(target.absolutePath)

            try {
                target.walkTopDown()
                    .maxDepth(5)
                    .onEnter { dir ->
                        onPathInspected(dir.absolutePath)
                        currentCoroutineContext().isActive
                    }
                    .forEach { file ->
                        if (!currentCoroutineContext().isActive) return@forEach
                        if (!file.isFile || file.length() <= 0) return@forEach

                        val path = file.absolutePath
                        if (visitedPaths.contains(path)) return@forEach
                        visitedPaths.add(path)

                        onPathInspected(path)

                        // Inspect byte signature
                        var fis: FileInputStream? = null
                        try {
                            fis = FileInputStream(file)
                            val readBytes = fis.read(buffer, 0, buffer.size)
                            if (readBytes > 16) {
                                val carveResult = signatureEngine.identifySignature(buffer.copyOf(readBytes), 0L)
                                
                                val isHiddenOrTrash = path.contains(".trash") || 
                                    path.contains(".trashed") || 
                                    path.contains(".thumbnails") || 
                                    path.contains("LOST.DIR") ||
                                    file.name.startsWith(".") ||
                                    path.contains(".pending-")

                                // Only emit if it is recovered from trash/LOST.DIR/thumbnails or an orphan carved file
                                if (isHiddenOrTrash || carveResult != null) {
                                    val source = when {
                                        path.contains("LOST.DIR") -> FileSource.LOST_DIR
                                        path.contains(".trash") || path.contains(".trashed") -> FileSource.MEDIASTORE_TRASH
                                        path.contains(".thumbnails") -> FileSource.HIDDEN_CACHE
                                        carveResult != null && file.extension.isEmpty() -> FileSource.FILE_CARVING
                                        else -> FileSource.APP_ORPHAN
                                    }

                                    val ext = carveResult?.extension ?: file.extension.ifEmpty { "bin" }
                                    val mime = carveResult?.mimeType ?: "application/octet-stream"
                                    val cat = carveResult?.category ?: ScanCategory.fromExtension(ext)
                                    val hexHeader = carveResult?.hexHeader ?: buffer.take(16).joinToString(" ") { "%02X".format(it) }

                                    val name = if (source == FileSource.LOST_DIR && carveResult != null && !file.name.contains(".")) {
                                        "${file.name}.${carveResult.extension}"
                                    } else {
                                        file.name
                                    }

                                    emit(
                                        RecoverableFile(
                                            id = UUID.randomUUID().toString(),
                                            name = name,
                                            originalPath = path,
                                            uri = null,
                                            category = cat,
                                            mimeType = mime,
                                            extension = ext,
                                            sizeBytes = file.length(),
                                            source = source,
                                            confidence = carveResult?.confidence ?: RecoveryConfidence.MEDIUM,
                                            timestamp = file.lastModified(),
                                            hexSnippet = hexHeader
                                        )
                                    )
                                }
                            }
                        } catch (e: Exception) {
                            // File might be in-use or permission denied
                        } finally {
                            try { fis?.close() } catch (_: Exception) {}
                        }
                    }
            } catch (e: Exception) {
                // Directory traversal error
            }
        }
    }.flowOn(Dispatchers.IO)
}
