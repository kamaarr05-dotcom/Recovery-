package com.recoverx.app.data.scanner

import android.content.Context
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.storage.StorageManager
import com.recoverx.app.data.model.StorageVolumeInfo

class StorageVolumeScanner(private val context: Context) {

    fun getAvailableStorageVolumes(): List<StorageVolumeInfo> {
        val list = mutableListOf<StorageVolumeInfo>()

        // 1. Primary Internal Storage
        try {
            val internalPath = Environment.getExternalStorageDirectory().absolutePath
            val stat = StatFs(internalPath)
            val blockSize = stat.blockSizeLong
            val totalBlocks = stat.blockCountLong
            val availableBlocks = stat.availableBlocksLong

            list.add(
                StorageVolumeInfo(
                    description = "Penyimpanan Internal Utama",
                    path = internalPath,
                    totalBytes = totalBlocks * blockSize,
                    freeBytes = availableBlocks * blockSize,
                    isRemovable = false,
                    isEmulated = Environment.isExternalStorageEmulated()
                )
            )
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 2. Secondary Volumes (MicroSD / USB OTG)
        try {
            val storageManager = context.getSystemService(Context.STORAGE_SERVICE) as? StorageManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N && storageManager != null) {
                for (volume in storageManager.storageVolumes) {
                    if (!volume.isPrimary) {
                        val desc = volume.getDescription(context) ?: "Penyimpanan Eksternal (SD Card)"
                        list.add(
                            StorageVolumeInfo(
                                description = desc,
                                path = "/storage/${volume.uuid ?: "external"}",
                                totalBytes = 0L,
                                freeBytes = 0L,
                                isRemovable = volume.isRemovable,
                                isEmulated = volume.isEmulated
                            )
                        )
                    }
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        return list
    }
}
