package com.recoverx.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.recoverx.app.data.model.FileSource
import com.recoverx.app.data.model.RecoverableFile
import com.recoverx.app.data.model.RecoveryConfidence
import com.recoverx.app.data.model.ScanCategory
import com.recoverx.app.ui.theme.*
import com.recoverx.app.ui.viewmodel.UiState

@Composable
fun FoundFilesScreen(
    state: UiState,
    onBackToHome: () -> Unit,
    onSelectCategory: (ScanCategory?) -> Unit,
    onToggleSelectFile: (String) -> Unit,
    onToggleSelectAll: () -> Unit,
    onOpenFilePreview: (RecoverableFile) -> Unit,
    onStartRecovery: () -> Unit,
    onSearchChanged: (String) -> Unit
) {
    val filteredFiles = state.foundFiles.filter { file ->
        val matchesCategory = state.selectedCategory == null || file.category == state.selectedCategory
        val matchesSearch = state.searchQuery.isEmpty() || file.name.contains(state.searchQuery, ignoreCase = true)
        matchesCategory && matchesSearch
    }

    Scaffold(
        containerColor = DarkBackground,
        bottomBar = {
            if (state.selectedCount > 0) {
                Surface(
                    color = DarkSurface,
                    tonalElevation = 8.dp,
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E293B))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 20.dp, vertical = 14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${state.selectedCount} File Terpilih",
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                fontSize = 15.sp
                            )
                            Text(
                                text = formatFileSize(state.selectedTotalBytes),
                                color = CyanLight,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }

                        Button(
                            onClick = onStartRecovery,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = CyanPrimary,
                                contentColor = DarkBackground
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.height(48.dp)
                        ) {
                            Icon(imageVector = Icons.Default.Download, contentDescription = null)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(text = "Pulihkan Sekarang", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(onClick = onBackToHome) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Kembali", tint = Color.White)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = "File Ditemukan",
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        fontSize = 17.sp
                    )
                    Text(
                        text = "${state.foundFiles.size} file siap dipulihkan",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )
                }

                TextButton(onClick = onToggleSelectAll) {
                    Text(
                        text = if (state.isAllSelected) "Batal" else "Semua",
                        color = CyanPrimary,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Search Bar
            OutlinedTextField(
                value = state.searchQuery,
                onValueChange = onSearchChanged,
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("Cari nama file atau ekstensi...", color = TextSecondary) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = DarkSurface,
                    unfocusedContainerColor = DarkSurface,
                    focusedBorderColor = CyanPrimary,
                    unfocusedBorderColor = Color(0xFF1E293B),
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Category Filter Pills
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                item {
                    CategoryPill(
                        label = "Semua (${state.foundFiles.size})",
                        isSelected = state.selectedCategory == null,
                        onClick = { onSelectCategory(null) }
                    )
                }

                items(ScanCategory.entries.filter { it != ScanCategory.OTHERS }) { cat ->
                    val count = state.foundFiles.count { it.category == cat }
                    if (count > 0) {
                        CategoryPill(
                            label = "${cat.displayName} ($count)",
                            isSelected = state.selectedCategory == cat,
                            onClick = { onSelectCategory(cat) }
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // File Results List
            if (filteredFiles.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.SearchOff,
                            contentDescription = null,
                            tint = TextSecondary,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Tidak ada file yang cocok",
                            color = TextSecondary,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(filteredFiles, key = { it.id }) { item ->
                        RecoverableFileCard(
                            file = item,
                            onToggleSelect = { onToggleSelectFile(item.id) },
                            onOpenPreview = { onOpenFilePreview(item) }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun CategoryPill(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(20.dp),
        color = if (isSelected) CyanPrimary else DarkSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) CyanPrimary else Color(0xFF1E293B)),
        modifier = Modifier.clickable { onClick() }
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) DarkBackground else Color.White,
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)
        )
    }
}

@Composable
private fun RecoverableFileCard(
    file: RecoverableFile,
    onToggleSelect: () -> Unit,
    onOpenPreview: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (file.isSelected) DarkSurfaceVariant else DarkSurface
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (file.isSelected) CyanPrimary else Color(0xFF1E293B)
        ),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onOpenPreview() }
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Checkbox(
                checked = file.isSelected,
                onCheckedChange = { onToggleSelect() },
                colors = CheckboxDefaults.colors(
                    checkedColor = CyanPrimary,
                    uncheckedColor = TextSecondary,
                    checkmarkColor = DarkBackground
                )
            )

            Spacer(modifier = Modifier.width(8.dp))

            // File Category Icon
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(getCategoryColor(file.category).copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = getCategoryIcon(file.category),
                    contentDescription = null,
                    tint = getCategoryColor(file.category),
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = file.name,
                    fontWeight = FontWeight.SemiBold,
                    color = Color.White,
                    fontSize = 14.sp,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = formatFileSize(file.sizeBytes),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        color = TextSecondary
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    // Source Tag
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = Color(0xFF1E293B)
                    ) {
                        Text(
                            text = when (file.source) {
                                FileSource.MEDIASTORE_TRASH -> "Trash"
                                FileSource.LOST_DIR -> "LOST.DIR"
                                FileSource.FILE_CARVING -> "Carved"
                                FileSource.HIDDEN_CACHE -> "Cache"
                                FileSource.APP_ORPHAN -> "Orphan"
                            },
                            fontSize = 10.sp,
                            color = CyanLight,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    // Confidence Indicator
                    if (file.confidence == RecoveryConfidence.HIGH) {
                        Text(
                            text = "100% Utuh",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = AccentGreen
                        )
                    }
                }
            }

            IconButton(onClick = onOpenPreview) {
                Icon(
                    imageVector = Icons.Default.ChevronRight,
                    contentDescription = "Detail",
                    tint = TextSecondary
                )
            }
        }
    }
}

fun formatFileSize(bytes: Long): String {
    if (bytes <= 0) return "0 B"
    val units = arrayOf("B", "KB", "MB", "GB", "TB")
    val digitGroups = (Math.log10(bytes.toDouble()) / Math.log10(1024.0)).toInt()
    return "%.1f %s".format(bytes / Math.pow(1024.0, digitGroups.toDouble()), units[digitGroups])
}

fun getCategoryIcon(category: ScanCategory): ImageVector = when (category) {
    ScanCategory.PHOTOS -> Icons.Default.Image
    ScanCategory.VIDEOS -> Icons.Default.Videocam
    ScanCategory.AUDIO -> Icons.Default.Audiotrack
    ScanCategory.DOCUMENTS -> Icons.Default.Description
    ScanCategory.ARCHIVES -> Icons.Default.Archive
    ScanCategory.APKS -> Icons.Default.Android
    ScanCategory.OTHERS -> Icons.Default.InsertDriveFile
}

fun getCategoryColor(category: ScanCategory): Color = when (category) {
    ScanCategory.PHOTOS -> CyanLight
    ScanCategory.VIDEOS -> Color(0xFFF43F5E)
    ScanCategory.AUDIO -> Color(0xFFA855F7)
    ScanCategory.DOCUMENTS -> Color(0xFF3B82F6)
    ScanCategory.ARCHIVES -> AccentAmber
    ScanCategory.APKS -> AccentGreen
    ScanCategory.OTHERS -> TextSecondary
}
