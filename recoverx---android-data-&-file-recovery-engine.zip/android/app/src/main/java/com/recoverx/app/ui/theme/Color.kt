package com.recoverx.app.ui.theme

import androidx.compose.ui.graphics.Color

val CyanPrimary = Color(0xFF06B6D4)
val CyanDark = Color(0xFF0891B2)
val CyanLight = Color(0xFF38BDF8)
val DarkBackground = Color(0xFF090D16)
val DarkSurface = Color(0xFF111827)
val DarkSurfaceVariant = Color(0xFF1F2937)
val TextPrimary = Color(0xFFF8FAFC)
val TextSecondary = Color(0xFF94A3B8)
val AccentGreen = Color(0xFF10B981)
val AccentAmber = Color(0xFFF59E0B)
val AccentRed = Color(0xFFEF4444)
