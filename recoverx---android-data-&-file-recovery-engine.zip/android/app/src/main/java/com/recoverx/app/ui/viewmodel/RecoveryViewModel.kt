package com.recoverx.app.ui.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.recoverx.app.data.carving.FileSignatureEngine
import com.recoverx.app.data.model.*
import com.recoverx.app.data.recovery.BatchRecoverySummary
import com.recoverx.app.data.recovery.RecoveryManager
import com.recoverx.app.data.scanner.HiddenStorageScanner
import com.recoverx.app.data.scanner.MediaStoreTrashScanner
import com.recoverx.app.data.scanner.StorageVolumeScanner
import com.recoverx.app.data.security.PermissionStatus
import com.recoverx.app.data.security.StoragePermissionHelper
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

sealed class ScreenState {
    object Home : ScreenState()
    object Scanning : ScreenState()
    object FoundFiles : ScreenState()
    data class Preview(val file: RecoverableFile) : ScreenState()
    data class Recovering(val currentFile: String, val progressFraction: Float) : ScreenState()
    data class Result(val summary: BatchRecoverySummary) : ScreenState()
}

enum class ScanMode(val title: String, val description: String) {
    FULL_DEEP_SCAN("Deep Carving & All Storage", "Memindai MediaStore, recycle bin, LOST.DIR, dan byte signature pada seluruh sektor penyimpanan"),
    MEDIASTORE_TRASH("Pemeriksaan MediaStore & Sampah", "Memindai file yang ditandai terhapus (IS_TRASHED=1) dan cache media internal"),
    LOST_DIR_RECOVERY("LOST.DIR & Orphan Sector", "Memindai dan merekonstruksi fragmen cluster yang hilang akibat crash atau unmount mendadak")
}

data class UiState(
    val currentScreen: ScreenState = ScreenState.Home,
    val permissionStatus: PermissionStatus,
    val storageVolumes: List<StorageVolumeInfo> = emptyList(),
    val selectedScanMode: ScanMode = ScanMode.FULL_DEEP_SCAN,
    val scanProgress: ScanProgress = ScanProgress(),
    val foundFiles: List<RecoverableFile> = emptyList(),
    val selectedCategory: ScanCategory? = null,
    val searchQuery: String = "",
    val isAllSelected: Boolean = false,
    val selectedCount: Int = 0,
    val selectedTotalBytes: Long = 0L,
    val isTargetDestinationDialogVisible: Boolean = false
)

class RecoveryViewModel(application: Application) : AndroidViewModel(application) {

    private val permissionHelper = StoragePermissionHelper(application)
    private val signatureEngine = FileSignatureEngine()
    private val mediaStoreScanner = MediaStoreTrashScanner(application)
    private val deepStorageScanner = com.recoverx.app.data.scanner.DeepStorageCarvingScanner(application, signatureEngine)
    private val thumbDatabaseCarver = com.recoverx.app.data.carving.ThumbnailDatabaseForensicCarver(signatureEngine)
    private val volumeScanner = StorageVolumeScanner(application)
    private val recoveryManager = RecoveryManager(application)

    private val _uiState = MutableStateFlow(
        UiState(
            permissionStatus = permissionHelper.checkPermissionStatus(),
            storageVolumes = volumeScanner.getAvailableStorageVolumes()
        )
    )
    val uiState: StateFlow<UiState> = _uiState.asStateFlow()

    private var scanJob: Job? = null
    private var scanStartTime = 0L

    fun refreshPermissions() {
        _uiState.update {
            it.copy(
                permissionStatus = permissionHelper.checkPermissionStatus(),
                storageVolumes = volumeScanner.getAvailableStorageVolumes()
            )
        }
    }

    fun setScanMode(mode: ScanMode) {
        _uiState.update { it.copy(selectedScanMode = mode) }
    }

    fun startScan() {
        scanJob?.cancel()
        scanStartTime = System.currentTimeMillis()

        _uiState.update {
            it.copy(
                currentScreen = ScreenState.Scanning,
                foundFiles = emptyList(),
                selectedCount = 0,
                selectedTotalBytes = 0L,
                scanProgress = ScanProgress(
                    isScanning = true,
                    currentMethod = _uiState.value.selectedScanMode.title
                )
            )
        }

        scanJob = viewModelScope.launch(Dispatchers.IO) {
            val collectedFiles = mutableListOf<RecoverableFile>()
            val counts = mutableMapOf<ScanCategory, Int>()
            var filesScanned = 0L

            // 1. Scan MediaStore Trashed (if selected or full)
            if (_uiState.value.selectedScanMode != ScanMode.LOST_DIR_RECOVERY) {
                _uiState.update {
                    it.copy(scanProgress = it.scanProgress.copy(currentMethod = "Memeriksa MediaStore & Recycle Bin"))
                }

                mediaStoreScanner.scanTrashedMedia().collect { item ->
                    collectedFiles.add(item)
                    counts[item.category] = (counts[item.category] ?: 0) + 1
                    filesScanned++

                    _uiState.update {
                        it.copy(
                            foundFiles = collectedFiles.toList(),
                            scanProgress = it.scanProgress.copy(
                                filesScannedCount = filesScanned,
                                filesFoundCount = collectedFiles.size.toLong(),
                                currentPath = item.originalPath,
                                categoryCounts = counts.toMap(),
                                elapsedTimeMs = System.currentTimeMillis() - scanStartTime
                            )
                        )
                    }
                }
            }

            // 2. Scan Hidden, DCIM Thumbnails, LOST.DIR & Byte Signatures
            if (_uiState.value.selectedScanMode != ScanMode.MEDIASTORE_TRASH) {
                _uiState.update {
                    it.copy(scanProgress = it.scanProgress.copy(currentMethod = "Memindai Sektor LOST.DIR, Thumbnails & File Signature Carving"))
                }

                deepStorageScanner.scanDeepStorage { path ->
                    filesScanned++
                    _uiState.update {
                        it.copy(
                            scanProgress = it.scanProgress.copy(
                                filesScannedCount = filesScanned,
                                currentPath = path,
                                elapsedTimeMs = System.currentTimeMillis() - scanStartTime
                            )
                        )
                    }
                }.collect { item ->
                    collectedFiles.add(item)
                    counts[item.category] = (counts[item.category] ?: 0) + 1

                    _uiState.update {
                        it.copy(
                            foundFiles = collectedFiles.toList(),
                            scanProgress = it.scanProgress.copy(
                                filesFoundCount = collectedFiles.size.toLong(),
                                categoryCounts = counts.toMap()
                            )
                        )
                    }
                }

                // 3. Deep Carve Embedded JPEG frames from .thumbdata databases (For permanently deleted photos)
                _uiState.update {
                    it.copy(scanProgress = it.scanProgress.copy(currentMethod = "Membedah Binary .thumbdata untuk Foto yang Terhapus Permanen"))
                }

                thumbDatabaseCarver.carveEmbeddedPhotosFromDatabases { currentFile, photosFound ->
                    filesScanned++
                    _uiState.update {
                        it.copy(
                            scanProgress = it.scanProgress.copy(
                                filesScannedCount = filesScanned,
                                currentPath = "DCIM/.thumbnails/$currentFile (Ekstraksi frame JPEG)",
                                elapsedTimeMs = System.currentTimeMillis() - scanStartTime
                            )
                        )
                    }
                }.collect { item ->
                    collectedFiles.add(item)
                    counts[item.category] = (counts[item.category] ?: 0) + 1

                    _uiState.update {
                        it.copy(
                            foundFiles = collectedFiles.toList(),
                            scanProgress = it.scanProgress.copy(
                                filesFoundCount = collectedFiles.size.toLong(),
                                categoryCounts = counts.toMap()
                            )
                        )
                    }
                }
            }

            // Finish scan
            _uiState.update {
                it.copy(
                    currentScreen = ScreenState.FoundFiles,
                    scanProgress = it.scanProgress.copy(
                        isScanning = false,
                        isFinished = true,
                        filesFoundCount = collectedFiles.size.toLong()
                    )
                )
            }
        }
    }

    fun cancelScan() {
        scanJob?.cancel()
        _uiState.update {
            it.copy(
                currentScreen = if (it.foundFiles.isNotEmpty()) ScreenState.FoundFiles else ScreenState.Home,
                scanProgress = it.scanProgress.copy(isScanning = false)
            )
        }
    }

    fun selectCategory(category: ScanCategory?) {
        _uiState.update { it.copy(selectedCategory = category) }
    }

    fun setSearchQuery(query: String) {
        _uiState.update { it.copy(searchQuery = query) }
    }

    fun toggleFileSelection(fileId: String) {
        _uiState.update { state ->
            val updated = state.foundFiles.map {
                if (it.id == fileId) it.copy(isSelected = !it.isSelected) else it
            }
            val count = updated.count { it.isSelected }
            val bytes = updated.filter { it.isSelected }.sumOf { it.sizeBytes }
            state.copy(
                foundFiles = updated,
                selectedCount = count,
                selectedTotalBytes = bytes,
                isAllSelected = count == updated.size && updated.isNotEmpty()
            )
        }
    }

    fun toggleSelectAll() {
        _uiState.update { state ->
            val target = !state.isAllSelected
            val updated = state.foundFiles.map { it.copy(isSelected = target) }
            val count = if (target) updated.size else 0
            val bytes = if (target) updated.sumOf { it.sizeBytes } else 0L
            state.copy(
                foundFiles = updated,
                selectedCount = count,
                selectedTotalBytes = bytes,
                isAllSelected = target
            )
        }
    }

    fun openPreview(file: RecoverableFile) {
        _uiState.update { it.copy(currentScreen = ScreenState.Preview(file)) }
    }

    fun backToFoundFiles() {
        _uiState.update { it.copy(currentScreen = ScreenState.FoundFiles) }
    }

    fun backToHome() {
        _uiState.update { it.copy(currentScreen = ScreenState.Home) }
    }

    fun showDestinationDialog() {
        _uiState.update { it.copy(isTargetDestinationDialogVisible = true) }
    }

    fun hideDestinationDialog() {
        _uiState.update { it.copy(isTargetDestinationDialogVisible = false) }
    }

    fun executeRecovery(targetTreeUri: Uri? = null) {
        hideDestinationDialog()
        val selected = _uiState.value.foundFiles.filter { it.isSelected }
        if (selected.isEmpty()) return

        _uiState.update {
            it.copy(currentScreen = ScreenState.Recovering(selected.first().name, 0f))
        }

        viewModelScope.launch(Dispatchers.IO) {
            val summary = recoveryManager.recoverFiles(selected, targetTreeUri) { index, item, _ ->
                val fraction = (index + 1).toFloat() / selected.size.toFloat()
                _uiState.update {
                    it.copy(currentScreen = ScreenState.Recovering(item.name, fraction))
                }
            }

            // Mark recovered in list
            val recoveredIds = summary.itemResults.filter { it.isSuccess }.map { it.file.id }.toSet()
            val updatedList = _uiState.value.foundFiles.map {
                if (recoveredIds.contains(it.id)) it.copy(isRecovered = true, isSelected = false) else it
            }

            _uiState.update {
                it.copy(
                    foundFiles = updatedList,
                    selectedCount = 0,
                    selectedTotalBytes = 0L,
                    currentScreen = ScreenState.Result(summary)
                )
            }
        }
    }
}
