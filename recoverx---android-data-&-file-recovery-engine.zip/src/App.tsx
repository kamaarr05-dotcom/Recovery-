import React, { useState, useEffect } from 'react';
import { PhoneFrame } from './components/PhoneFrame';
import { HomeScreen, ScanMode } from './components/HomeScreen';
import { ScanningScreen } from './components/ScanningScreen';
import { FoundFilesScreen } from './components/FoundFilesScreen';
import { PreviewScreen } from './components/PreviewScreen';
import { RecoveryResultModal } from './components/RecoveryResultModal';
import { AndroidProjectHub } from './components/AndroidProjectHub';
import { HexLab } from './components/HexLab';
import { 
  CarvedFile, identifyBinarySignature, toHexDump, 
  computeSHA256, formatBytes 
} from './engine/carver';
import { generateGenuineSampleFiles } from './engine/sampleGenerator';
import { FolderCheck, Save, Sparkles, FolderOpen, X } from 'lucide-react';

type ScreenType = 'HOME' | 'SCANNING' | 'FOUND_FILES' | 'PREVIEW' | 'ANDROID_HUB' | 'HEX_LAB';

export default function App() {
  const [currentScreen, setCurrentScreen] = useState<ScreenType>('HOME');
  const [isPhoneView, setIsPhoneView] = useState<boolean>(true);
  const [selectedScanMode, setSelectedScanMode] = useState<ScanMode>('FULL_DEEP_SCAN');

  // Scanner state
  const [currentMethod, setCurrentMethod] = useState<string>('Memeriksa MediaStore & Kluster LOST.DIR');
  const [currentPath, setCurrentPath] = useState<string>('');
  const [foundFiles, setFoundFiles] = useState<CarvedFile[]>([]);
  const [previewFile, setPreviewFile] = useState<CarvedFile | null>(null);

  // Search & Filter state
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null);

  // Destination & Recovery modal
  const [isDestinationDialogOpen, setIsDestinationDialogOpen] = useState<boolean>(false);
  const [destinationFolder, setDestinationFolder] = useState<string>('/storage/emulated/0/Download/RecoverX_Restored');
  const [recoveredFiles, setRecoveredFiles] = useState<CarvedFile[]>([]);
  const [isResultModalOpen, setIsResultModalOpen] = useState<boolean>(false);

  // Category counts
  const categoryCounts = foundFiles.reduce((acc, f) => {
    acc[f.category] = (acc[f.category] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  // Load genuine sample files on initialization
  useEffect(() => {
    generateGenuineSampleFiles().then((samples) => {
      setFoundFiles(samples);
    });
  }, []);

  // Real scanning simulation with sector traverse
  const handleStartScan = async () => {
    setCurrentScreen('SCANNING');
    setFoundFiles([]);

    const paths = [
      '/storage/emulated/0/MediaStore/Images/trashed',
      '/storage/emulated/0/.trash/DCIM_20240915_FamilyTrip.jpg',
      '/storage/emulated/0/LOST.DIR/14092',
      '/storage/emulated/0/Download/.trash/Kontrak_Kerja_Recovered.pdf',
      '/storage/emulated/0/Android/media/com.whatsapp/WhatsApp/Media/.trash/Sticker_882.webp',
      '/storage/emulated/0/DCIM/.thumbnails/cache_photo_raw.bin',
      '/storage/emulated/0/LOST.DIR/99824'
    ];

    const genuineSamples = await generateGenuineSampleFiles();
    const collected: CarvedFile[] = [];

    for (let i = 0; i < paths.length; i++) {
      setCurrentPath(paths[i]);
      if (i < 2) {
        setCurrentMethod('Memeriksa MediaStore Trash (IS_TRASHED=1)');
      } else if (i < 5) {
        setCurrentMethod('Memindai Kluster LOST.DIR & Ekstraksi Signature');
      } else {
        setCurrentMethod('File Carving Biner Sektor Storage (SOI/EOI, ftyp, PK)');
      }

      await new Promise(resolve => setTimeout(resolve, 600));

      if (genuineSamples[i]) {
        collected.push(genuineSamples[i]);
        setFoundFiles([...collected]);
      }
    }

    setCurrentScreen('FOUND_FILES');
  };

  // Real user file / folder upload scanner
  const handleLoadLocalFiles = async (files: FileList) => {
    setCurrentScreen('SCANNING');
    setCurrentMethod('Menganalisis Signature Biner File Pengguna');
    const carvedList: CarvedFile[] = [];

    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      setCurrentPath(file.name);

      try {
        const buffer = await file.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        const signature = identifyBinarySignature(bytes);
        const sha = await computeSHA256(buffer);
        const hex = toHexDump(bytes, 16);

        const category = signature?.category || 'OTHERS';
        const ext = signature?.extension || file.name.split('.').pop() || 'bin';
        const mime = signature?.mimeType || file.type || 'application/octet-stream';

        const blob = new Blob([bytes], { type: mime });
        const dataUrl = mime.startsWith('image/') ? URL.createObjectURL(blob) : undefined;

        carvedList.push({
          id: `carved_user_${i}_${Date.now()}`,
          name: file.name,
          originalPath: file.webkitRelativePath || `/storage/emulated/0/Download/${file.name}`,
          blob,
          dataUrl,
          category,
          mimeType: mime,
          extension: ext,
          sizeBytes: file.size,
          source: 'FILE_CARVING',
          confidence: signature?.confidence || 'MEDIUM',
          headerOffset: 0,
          timestamp: file.lastModified || Date.now(),
          hexHeader: hex,
          sha256: sha,
          isSelected: true
        });

        setFoundFiles([...carvedList]);
      } catch (err) {
        console.error('Error carving file:', err);
      }
    }

    setCurrentScreen('FOUND_FILES');
  };

  // Selection handlers
  const handleToggleSelect = (id: string) => {
    setFoundFiles(prev =>
      prev.map(f => (f.id === id ? { ...f, isSelected: !f.isSelected } : f))
    );
  };

  const handleToggleSelectAll = () => {
    const allSelected = foundFiles.length > 0 && foundFiles.every(f => f.isSelected);
    setFoundFiles(prev => prev.map(f => ({ ...f, isSelected: !allSelected })));
  };

  // Recovery flow
  const handleOpenDestinationDialog = () => {
    setIsDestinationDialogOpen(true);
  };

  const handleConfirmRecovery = (targetFolder: string) => {
    setDestinationFolder(targetFolder);
    setIsDestinationDialogOpen(false);

    const selected = foundFiles.filter(f => f.isSelected);
    if (selected.length === 0) return;

    setRecoveredFiles(selected);
    setIsResultModalOpen(true);
  };

  const handleRecoverSingle = (file: CarvedFile) => {
    setRecoveredFiles([file]);
    setIsResultModalOpen(true);
  };

  return (
    <PhoneFrame isPhoneView={isPhoneView} onToggleView={() => setIsPhoneView(!isPhoneView)}>
      {/* Screen Router */}
      {currentScreen === 'HOME' && (
        <HomeScreen
          selectedMode={selectedScanMode}
          onSelectMode={setSelectedScanMode}
          onStartScan={handleStartScan}
          onLoadLocalFiles={handleLoadLocalFiles}
          onOpenAndroidHub={() => setCurrentScreen('ANDROID_HUB')}
          onOpenHexLab={() => setCurrentScreen('HEX_LAB')}
        />
      )}

      {currentScreen === 'SCANNING' && (
        <ScanningScreen
          currentMethod={currentMethod}
          currentPath={currentPath}
          filesFoundCount={foundFiles.length}
          categoryCounts={categoryCounts}
          onCancelScan={() => setCurrentScreen(foundFiles.length > 0 ? 'FOUND_FILES' : 'HOME')}
        />
      )}

      {currentScreen === 'FOUND_FILES' && (
        <FoundFilesScreen
          files={foundFiles}
          searchQuery={searchQuery}
          selectedCategory={selectedCategory}
          onSearchChange={setSearchQuery}
          onSelectCategory={setSelectedCategory}
          onToggleSelect={handleToggleSelect}
          onToggleSelectAll={handleToggleSelectAll}
          onOpenFilePreview={(file) => {
            setPreviewFile(file);
            setCurrentScreen('PREVIEW');
          }}
          onStartRecovery={handleOpenDestinationDialog}
          onBack={() => setCurrentScreen('HOME')}
        />
      )}

      {currentScreen === 'PREVIEW' && previewFile && (
        <PreviewScreen
          file={previewFile}
          onBack={() => setCurrentScreen('FOUND_FILES')}
          onToggleSelect={(id) => {
            handleToggleSelect(id);
            setPreviewFile(prev => prev ? { ...prev, isSelected: !prev.isSelected } : null);
          }}
          onRecoverSingle={handleRecoverSingle}
        />
      )}

      {currentScreen === 'ANDROID_HUB' && (
        <AndroidProjectHub onBack={() => setCurrentScreen('HOME')} />
      )}

      {currentScreen === 'HEX_LAB' && (
        <HexLab onBack={() => setCurrentScreen('HOME')} />
      )}

      {/* Destination Picker Modal */}
      {isDestinationDialogOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-slate-900 border border-slate-800 rounded-3xl max-w-sm w-full p-5 space-y-4 shadow-2xl animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <FolderOpen className="w-5 h-5 text-cyan-400" />
                <h3 className="text-base font-bold text-white">Pilih Lokasi Pemulihan</h3>
              </div>
              <button
                onClick={() => setIsDestinationDialogOpen(false)}
                className="p-1 hover:bg-slate-800 rounded-lg text-slate-400"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <p className="text-xs text-slate-400 leading-relaxed">
              Untuk mencegah overwriting (menimpa sektor yang belum selesai dipulihkan), pilih folder tujuan yang aman:
            </p>

            <div className="space-y-2">
              <button
                onClick={() => handleConfirmRecovery('/storage/emulated/0/Download/RecoverX_Restored')}
                className="w-full text-left p-3.5 bg-slate-800/80 hover:bg-slate-800 border border-cyan-500/80 rounded-2xl transition cursor-pointer"
              >
                <p className="text-xs font-bold text-white">Folder Standar RecoverX</p>
                <p className="text-[11px] font-mono text-cyan-400 mt-0.5">Download/RecoverX_Restored</p>
              </button>

              <button
                onClick={() => handleConfirmRecovery('/storage/sdcard0/Recovered_Media')}
                className="w-full text-left p-3.5 bg-slate-950 hover:bg-slate-800/60 border border-slate-800 rounded-2xl transition cursor-pointer"
              >
                <p className="text-xs font-bold text-slate-200">Kartu Memori Eksternal (SD Card)</p>
                <p className="text-[11px] font-mono text-slate-400 mt-0.5">/storage/sdcard0/Recovered_Media</p>
              </button>
            </div>

            <div className="pt-2">
              <button
                onClick={() => setIsDestinationDialogOpen(false)}
                className="w-full py-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 font-semibold rounded-xl text-xs transition cursor-pointer"
              >
                Batal
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Recovery Result Modal */}
      {isResultModalOpen && (
        <RecoveryResultModal
          files={recoveredFiles}
          destinationPath={destinationFolder}
          onClose={() => setIsResultModalOpen(false)}
        />
      )}
    </PhoneFrame>
  );
}
