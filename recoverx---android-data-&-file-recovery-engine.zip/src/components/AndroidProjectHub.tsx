import React, { useState } from 'react';
import { 
  ArrowLeft, Download, FileCode, Check, Copy, Terminal, 
  Layers, ShieldAlert, Cpu, Sparkles, FolderTree, ExternalLink 
} from 'lucide-react';
import JSZip from 'jszip';
import { ANDROID_PROJECT_FILES } from '../engine/androidProjectFiles';

interface AndroidProjectHubProps {
  onBack: () => void;
}

export const AndroidProjectHub: React.FC<AndroidProjectHubProps> = ({ onBack }) => {
  const [selectedFileIndex, setSelectedFileIndex] = useState(0);
  const [copied, setCopied] = useState(false);
  const [isZipping, setIsZipping] = useState(false);

  const currentFile = ANDROID_PROJECT_FILES[selectedFileIndex];

  const handleCopyCode = () => {
    navigator.clipboard.writeText(currentFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadFullProjectZip = async () => {
    setIsZipping(true);
    try {
      const zip = new JSZip();
      const rootFolder = zip.folder("RecoverX-Android") || zip;

      // Add all project files
      for (const item of ANDROID_PROJECT_FILES) {
        rootFolder.file(item.path, item.content);
      }

      // Add Gradle wrapper scripts
      rootFolder.file("gradlew", `#!/usr/bin/env sh
exec gradle "$@"
`);
      rootFolder.file("gradlew.bat", `@rem Gradle wrapper script
gradle %*
`);

      // Add comprehensive README
      rootFolder.file("README.md", `# RecoverX - Production Android Data & File Recovery Engine

Project ini adalah source code aplikasi Android asli yang siap di-build dengan Android Studio.

## 🛠️ Langkah Menjalankan:
1. Buka Android Studio (2024+ Ladybug / Iguana).
2. Pilih "Open Project" -> Arahkan ke folder hasil ekstrak ini.
3. Tunggu Gradle sync selesai.
4. Hubungkan HP Android asli via USB Debugging.
5. Klik Run 'app' (Shift+F10) atau jalankan command line:
   \`\`\`bash
   ./gradlew assembleDebug
   \`\`\`
APK hasil build akan berada di: \`app/build/outputs/apk/debug/app-debug.apk\`
`);

      const blob = await zip.generateAsync({ type: "blob" });
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = "RecoverX-Android-Project.zip";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error(err);
    } finally {
      setIsZipping(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 sm:p-6 space-y-5 text-slate-100 overflow-y-auto">
      {/* Top Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-slate-800 rounded-xl text-slate-300 transition cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-cyan-400" />
              Source Code Android & Arsitektur Produksi
            </h2>
            <p className="text-xs text-slate-400">
              Kotlin • Jetpack Compose • Material 3 • Coroutines • MediaStore API
            </p>
          </div>
        </div>

        {/* Download Full Zip Button */}
        <button
          onClick={handleDownloadFullProjectZip}
          disabled={isZipping}
          className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-950 font-bold rounded-xl text-xs shadow-md shadow-cyan-500/20 transition cursor-pointer disabled:opacity-50"
        >
          <Download className="w-4 h-4 stroke-[2.5]" />
          <span>{isZipping ? 'Sedang Memaketkan...' : 'Unduh Project Android (.ZIP)'}</span>
        </button>
      </div>

      {/* Engineering Highlights Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs">
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 space-y-1">
          <div className="flex items-center gap-2 text-cyan-400 font-bold">
            <Cpu className="w-4 h-4" />
            <span>FileSignatureEngine.kt</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Mesin carving biner murni mendeteksi JPEG SOI/EOI, PNG magic chunk, MP4 ftyp atom, PDF trailer %%EOF, dan ZIP/APK PK header.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 space-y-1">
          <div className="flex items-center gap-2 text-cyan-400 font-bold">
            <FolderTree className="w-4 h-4" />
            <span>MediaStoreTrashScanner.kt</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Mengeksekusi query resmi Android 11+ MediaStore dengan MATCH_ONLY untuk memulihkan file recycle bin sistem.
          </p>
        </div>

        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3.5 space-y-1">
          <div className="flex items-center gap-2 text-cyan-400 font-bold">
            <Terminal className="w-4 h-4" />
            <span>RecoveryManager.kt</span>
          </div>
          <p className="text-[11px] text-slate-400">
            Menulis data via Storage Access Framework (SAF), verifikasi hash SHA-256 byte-by-byte, dan memicu MediaScannerConnection.
          </p>
        </div>
      </div>

      {/* Code Browser Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 flex-1">
        {/* File Tree Column */}
        <div className="bg-slate-900 border border-slate-800 rounded-2xl p-3 space-y-1 overflow-y-auto max-h-[500px]">
          <label className="text-[11px] font-bold text-slate-400 uppercase tracking-wider px-2 py-1 block">
            Struktur Berkas Android
          </label>
          {ANDROID_PROJECT_FILES.map((file, idx) => (
            <button
              key={idx}
              onClick={() => setSelectedFileIndex(idx)}
              className={`w-full text-left p-2.5 rounded-xl text-xs font-mono transition flex items-center justify-between cursor-pointer ${
                selectedFileIndex === idx
                  ? 'bg-cyan-950/80 border border-cyan-800/80 text-cyan-300 font-semibold'
                  : 'hover:bg-slate-800/60 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2 truncate">
                <FileCode className="w-3.5 h-3.5 shrink-0 text-cyan-400" />
                <span className="truncate">{file.path}</span>
              </div>
            </button>
          ))}
        </div>

        {/* Code Content Column */}
        <div className="lg:col-span-2 bg-slate-950 border border-slate-800 rounded-2xl p-4 flex flex-col overflow-hidden max-h-[500px]">
          <div className="flex items-center justify-between pb-3 border-b border-slate-800 text-xs">
            <div>
              <p className="font-mono font-bold text-cyan-400">{currentFile.path}</p>
              <p className="text-[11px] text-slate-400">{currentFile.description}</p>
            </div>
            <button
              onClick={handleCopyCode}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition cursor-pointer"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Tersalin' : 'Salin'}</span>
            </button>
          </div>

          <pre className="flex-1 overflow-auto p-3 text-[11px] font-mono text-slate-300 leading-relaxed scrollbar-thin">
            {currentFile.content}
          </pre>
        </div>
      </div>

      {/* Build & Run Guide */}
      <div className="bg-slate-900 border border-slate-800 rounded-2xl p-4 text-xs space-y-2">
        <h4 className="font-bold text-white flex items-center gap-2">
          <Terminal className="w-4 h-4 text-cyan-400" />
          Cara Kompilasi & Install ke Smartphone Android Nyata
        </h4>
        <div className="bg-slate-950 p-3 rounded-xl border border-slate-800 font-mono text-slate-300 space-y-1">
          <p className="text-slate-500"># 1. Unduh dan ekstrak file ZIP project RecoverX</p>
          <p className="text-slate-500"># 2. Buka di Android Studio atau jalankan perintah Gradle berikut:</p>
          <p className="text-cyan-400">cd RecoverX-Android</p>
          <p className="text-cyan-400">./gradlew assembleDebug</p>
          <p className="text-slate-500"># 3. Pasang APK langsung ke HP via ADB:</p>
          <p className="text-emerald-400">adb install app/build/outputs/apk/debug/app-debug.apk</p>
        </div>
      </div>
    </div>
  );
};
