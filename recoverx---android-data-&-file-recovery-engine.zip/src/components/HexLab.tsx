import React, { useState } from 'react';
import { 
  ArrowLeft, Binary, Upload, Download, Search, CheckCircle2, 
  AlertTriangle, ShieldCheck, FileCheck, Layers
} from 'lucide-react';
import { identifyBinarySignature, toHexDump, formatBytes, computeSHA256 } from '../engine/carver';

interface HexLabProps {
  onBack: () => void;
}

export const HexLab: React.FC<HexLabProps> = ({ onBack }) => {
  const [hexData, setHexData] = useState<Uint8Array | null>(null);
  const [fileName, setFileName] = useState<string>('sample_sector_dump.bin');
  const [detection, setDetection] = useState<any>(null);
  const [sha256, setSha256] = useState<string>('');

  // Default sample JPEG buffer for immediate exploration
  React.useEffect(() => {
    const sample = new Uint8Array([
      0xFF, 0xD8, 0xFF, 0xE0, 0x00, 0x10, 0x4A, 0x46, 0x49, 0x46, 0x00, 0x01, 0x01, 0x01, 0x00, 0x48,
      0x00, 0x48, 0x00, 0x00, 0xFF, 0xDB, 0x00, 0x43, 0x00, 0x08, 0x06, 0x06, 0x07, 0x06, 0x05, 0x08,
      0x07, 0x07, 0x07, 0x09, 0x09, 0x08, 0x0A, 0x0C, 0x14, 0x0D, 0x0C, 0x0B, 0x0B, 0x0C, 0x19, 0x12,
      0x13, 0x0F, 0x14, 0x1D, 0x1A, 0x1F, 0x1E, 0x1D, 0x1A, 0x1C, 0x1C, 0x20, 0x24, 0x2E, 0x27, 0x20,
      0x22, 0x2C, 0x23, 0x1C, 0x1C, 0x28, 0x37, 0x29, 0x2C, 0x30, 0x31, 0x34, 0x34, 0x34, 0x1F, 0x27,
      0x39, 0x3D, 0x38, 0x32, 0x3C, 0x2E, 0x33, 0x34, 0x32, 0xFF, 0xC0, 0x00, 0x0B, 0x08, 0x00, 0x01,
      0x00, 0x01, 0x01, 0x01, 0x11, 0x00, 0xFF, 0xC4, 0x00, 0x1F, 0x00, 0x00, 0x01, 0x05, 0x01, 0x01,
      0x01, 0x01, 0x01, 0x01, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x01, 0x02, 0x03, 0x04,
      0x05, 0x06, 0x07, 0x08, 0x09, 0x0A, 0x0B, 0xFF, 0xDA, 0x00, 0x08, 0x01, 0x01, 0x00, 0x00, 0x3F,
      0x00, 0x7F, 0x00, 0xFF, 0xD9
    ]);
    setHexData(sample);
    const result = identifyBinarySignature(sample);
    setDetection(result);
    computeSHA256(sample.buffer).then(setSha256);
  }, []);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setFileName(file.name);
    const reader = new FileReader();
    reader.onload = async () => {
      if (reader.result instanceof ArrayBuffer) {
        const bytes = new Uint8Array(reader.result);
        setHexData(bytes);
        const result = identifyBinarySignature(bytes);
        setDetection(result);
        const hash = await computeSHA256(bytes.buffer);
        setSha256(hash);
      }
    };
    reader.readAsArrayBuffer(file);
  };

  const handleDownloadCarved = () => {
    if (!hexData || !detection) return;
    const blob = new Blob([hexData.buffer as ArrayBuffer], { type: detection.mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `Carved_${fileName.replace(/\.[^/.]+$/, "")}.${detection.extension}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  // Generate Hex rows (16 bytes per row)
  const renderHexRows = () => {
    if (!hexData) return null;
    const rows = [];
    const limit = Math.min(hexData.length, 512); // display first 512 bytes

    for (let i = 0; i < limit; i += 16) {
      const offsetHex = i.toString(16).padStart(8, '0').toUpperCase();
      const chunk = hexData.slice(i, i + 16);
      
      const hexParts = Array.from(chunk).map(b => b.toString(16).padStart(2, '0').toUpperCase());
      while (hexParts.length < 16) hexParts.push('  ');

      const asciiPart = Array.from(chunk).map(b => (b >= 32 && b <= 126 ? String.fromCharCode(b) : '.')).join('');

      rows.push(
        <div key={i} className="flex items-center gap-4 py-0.5 hover:bg-slate-900/60 font-mono text-[11px]">
          <span className="text-cyan-400 select-none w-20">{offsetHex}</span>
          <div className="flex-1 grid grid-cols-16 gap-1 text-slate-200">
            {hexParts.map((h, idx) => (
              <span 
                key={idx} 
                className={`${i + idx < 4 ? 'text-emerald-400 font-bold bg-emerald-950/40 px-0.5 rounded' : ''}`}
              >
                {h}
              </span>
            ))}
          </div>
          <span className="text-slate-400 select-none w-36 border-l border-slate-800 pl-3">
            {asciiPart}
          </span>
        </div>
      );
    }
    return rows;
  };

  return (
    <div className="flex-1 flex flex-col p-4 sm:p-6 space-y-4 text-slate-100 overflow-y-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
        <div className="flex items-center gap-3">
          <button
            onClick={onBack}
            className="p-2 hover:bg-slate-800 rounded-xl text-slate-300 transition cursor-pointer"
          >
            <ArrowLeft className="w-5 h-5" />
          </button>
          <div>
            <h2 className="text-lg font-bold text-white flex items-center gap-2">
              <Binary className="w-5 h-5 text-cyan-400" />
              Hex Forensics & Carving Lab
            </h2>
            <p className="text-xs text-slate-400">
              Analisis struktur byte, deteksi magic numbers, dan pemotongan biner
            </p>
          </div>
        </div>

        {/* Upload file to inspect */}
        <label className="flex items-center justify-center gap-2 px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 font-semibold rounded-xl text-xs transition cursor-pointer">
          <Upload className="w-4 h-4 text-cyan-400" />
          <span>Upload File / Dump Sektor</span>
          <input type="file" className="hidden" onChange={handleFileUpload} />
        </label>
      </div>

      {/* Detection Banner */}
      {detection ? (
        <div className="bg-emerald-950/30 border border-emerald-800/60 rounded-2xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2 bg-emerald-500/20 text-emerald-400 rounded-xl mt-0.5">
              <CheckCircle2 className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-sm text-white">Signature Valid Terdeteksi: {detection.signatureName}</span>
                <span className="text-[10px] font-mono bg-emerald-900/60 text-emerald-300 px-2 py-0.5 rounded border border-emerald-700">
                  .{detection.extension.toUpperCase()}
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1">
                MIME: <span className="font-mono text-cyan-300">{detection.mimeType}</span> • Ukuran: <span className="font-mono text-white">{formatBytes(hexData?.length || 0)}</span>
              </p>
              {sha256 && (
                <p className="text-[10px] font-mono text-slate-400 mt-1 truncate max-w-lg">
                  SHA-256: {sha256}
                </p>
              )}
            </div>
          </div>

          <button
            onClick={handleDownloadCarved}
            className="flex items-center justify-center gap-2 px-4 py-2.5 bg-gradient-to-r from-emerald-500 to-teal-400 hover:from-emerald-400 hover:to-teal-300 text-slate-950 font-bold rounded-xl text-xs shadow-md shadow-emerald-500/20 transition cursor-pointer"
          >
            <Download className="w-4 h-4 stroke-[2.5]" />
            <span>Ekstrak & Unduh File Terpulihkan</span>
          </button>
        </div>
      ) : (
        <div className="bg-amber-950/30 border border-amber-800/60 rounded-2xl p-4 flex items-center gap-3">
          <AlertTriangle className="w-5 h-5 text-amber-400" />
          <p className="text-xs text-amber-200">
            Signature tidak dikenal pada 16 byte pertama. Format mungkin terenkripsi atau data acak tak berekstensi.
          </p>
        </div>
      )}

      {/* Hex Dump Viewer */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 flex flex-col space-y-3">
        <div className="flex items-center justify-between text-xs pb-2 border-b border-slate-800/80">
          <span className="font-mono font-bold text-slate-300">File: {fileName}</span>
          <span className="text-[11px] text-slate-500">Menampilkan 512 byte pertama</span>
        </div>

        <div className="overflow-x-auto">
          <div className="min-w-[580px]">
            {renderHexRows()}
          </div>
        </div>
      </div>
    </div>
  );
};
