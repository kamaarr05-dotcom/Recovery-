import React, { useRef } from 'react';
import { 
  RotateCcw, HardDrive, ShieldCheck, Search, Radio, FolderArchive, 
  Trash2, Upload, FileCode2, Binary, CheckCircle2, AlertTriangle, ArrowRight,
  Info, HelpCircle, Layers, Image as ImageIcon
} from 'lucide-react';

export type ScanMode = 'FULL_DEEP_SCAN' | 'MEDIASTORE_TRASH' | 'LOST_DIR_RECOVERY';

interface HomeScreenProps {
  selectedMode: ScanMode;
  onSelectMode: (mode: ScanMode) => void;
  onStartScan: () => void;
  onLoadLocalFiles: (files: FileList) => void;
  onOpenAndroidHub: () => void;
  onOpenHexLab: () => void;
}

export const HomeScreen: React.FC<HomeScreenProps> = ({
  selectedMode,
  onSelectMode,
  onStartScan,
  onLoadLocalFiles,
  onOpenAndroidHub,
  onOpenHexLab
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      onLoadLocalFiles(e.target.files);
    }
  };

  return (
    <div className="flex-1 flex flex-col p-4 sm:p-5 pb-8 space-y-5">
      {/* Brand Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center text-slate-950 shadow-lg shadow-cyan-500/20">
            <RotateCcw className="w-5 h-5 stroke-[2.5]" />
          </div>
          <div>
            <h1 className="text-xl font-bold tracking-tight text-white flex items-center gap-2">
              RecoverX
              <span className="text-[10px] font-mono uppercase bg-cyan-950 text-cyan-400 border border-cyan-800/80 px-1.5 py-0.5 rounded">
                v1.0.0
              </span>
            </h1>
            <p className="text-xs text-slate-400">Mesin Pemulihan Data Nyata Android</p>
          </div>
        </div>

        {/* Security / Permission Badge */}
        <div className="flex items-center gap-1.5 bg-emerald-950/60 border border-emerald-800/60 text-emerald-400 px-2.5 py-1 rounded-full text-[11px] font-medium">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>All Files Access</span>
        </div>
      </div>

      {/* Storage Status Card */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 shadow-sm">
        <div className="flex items-center justify-between text-xs mb-3">
          <div className="flex items-center gap-2 text-slate-200 font-semibold">
            <HardDrive className="w-4 h-4 text-cyan-400" />
            <span>Penyimpanan Internal Utama</span>
          </div>
          <span className="font-mono text-[11px] text-slate-400">/storage/emulated/0</span>
        </div>

        {/* Progress Meter */}
        <div className="w-full bg-slate-800 h-2.5 rounded-full overflow-hidden mb-2.5">
          <div className="bg-gradient-to-r from-cyan-500 to-blue-500 h-full rounded-full w-[68%]" />
        </div>

        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-400">Terpakai: 86.4 GB / 128.0 GB</span>
          <span className="font-semibold text-cyan-400">Tersedia: 41.6 GB</span>
        </div>
      </div>

      {/* Honest Forensic Architecture Banner & Permanent Deletion Explanation */}
      <div className="bg-gradient-to-br from-slate-900 to-cyan-950/30 border border-cyan-900/40 rounded-2xl p-3.5 space-y-2.5 text-xs">
        <div className="flex gap-2.5">
          <ShieldCheck className="w-5 h-5 text-cyan-400 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <p className="font-bold text-slate-200">Apakah HP Anda Harus di-Root?</p>
            <p className="text-slate-400 leading-relaxed text-[11px]">
              Jawabannya: <strong>TIDAK HARUS</strong>, kecuali jika Anda ingin membaca sektor hardware mentah yang belum tertimpa sama sekali.
            </p>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-1">
          <div className="bg-slate-950/80 border border-slate-800 p-2.5 rounded-xl space-y-1">
            <div className="flex items-center gap-1.5 text-cyan-400 font-bold text-[11px]">
              <span className="w-2 h-2 rounded-full bg-cyan-400" />
              <span>Metode 1: Tanpa Root (Aman)</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed">
              Memulihkan dari <strong>DCIM/.thumbnails</strong> (foto cache full-res), <strong>LOST.DIR</strong> (fragmen sektor unallocated), dan <strong>Sampah Sistem</strong>. Anda tidak perlu membongkar garansi atau meroot HP.
            </p>
          </div>

          <div className="bg-slate-950/80 border border-amber-900/40 p-2.5 rounded-xl space-y-1">
            <div className="flex items-center gap-1.5 text-amber-400 font-bold text-[11px]">
              <AlertTriangle className="w-3 h-3 text-amber-400" />
              <span>Metode 2: Dengan Root (Tingkat Lanjut)</span>
            </div>
            <p className="text-[10px] text-slate-400 leading-relaxed">
              Jika di-root, modul <code className="text-amber-300 font-mono text-[9px]">RootBlockDeviceCarver</code> akan membaca partisi fisik <code className="text-amber-300 font-mono text-[9px]">/dev/block/bootdevice/by-name/userdata</code> langsung untuk membedah data raw.
            </p>
          </div>
        </div>
      </div>

      {/* Mode Selector */}
      <div className="space-y-2.5">
        <div className="flex items-center justify-between">
          <label className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Pilih Metode Pemindaian
          </label>
        </div>

        {/* Option 1: Full Deep Carving */}
        <div 
          onClick={() => onSelectMode('FULL_DEEP_SCAN')}
          className={`p-3.5 rounded-2xl border transition cursor-pointer flex items-start gap-3.5 ${
            selectedMode === 'FULL_DEEP_SCAN'
              ? 'bg-slate-800/90 border-cyan-500 shadow-md shadow-cyan-950/30'
              : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-800/40'
          }`}
        >
          <div className={`p-2 rounded-xl mt-0.5 ${selectedMode === 'FULL_DEEP_SCAN' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>
            <Radio className="w-4 h-4" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-slate-100">Full Deep Carving & All Storage</span>
              <span className="text-[9px] font-bold bg-cyan-500/20 text-cyan-300 px-1.5 py-0.5 rounded border border-cyan-500/30">
                REKOMENDASI
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Memindai MediaStore, sampah tersembunyi, kluster LOST.DIR, dan membedah signature biner di seluruh sektor.
            </p>
          </div>
          <div className={`w-4 h-4 rounded-full border-2 mt-1 flex items-center justify-center ${
            selectedMode === 'FULL_DEEP_SCAN' ? 'border-cyan-400 bg-cyan-400' : 'border-slate-600'
          }`}>
            {selectedMode === 'FULL_DEEP_SCAN' && <div className="w-1.5 h-1.5 bg-slate-950 rounded-full" />}
          </div>
        </div>

        {/* Option 2: MediaStore & Trash Only */}
        <div 
          onClick={() => onSelectMode('MEDIASTORE_TRASH')}
          className={`p-3.5 rounded-2xl border transition cursor-pointer flex items-start gap-3.5 ${
            selectedMode === 'MEDIASTORE_TRASH'
              ? 'bg-slate-800/90 border-cyan-500 shadow-md shadow-cyan-950/30'
              : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-800/40'
          }`}
        >
          <div className={`p-2 rounded-xl mt-0.5 ${selectedMode === 'MEDIASTORE_TRASH' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>
            <Trash2 className="w-4 h-4" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-slate-100">MediaStore & Recycle Bin</span>
            </div>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Memeriksa file dengan status <code className="text-cyan-300">IS_TRASHED = 1</code> dan cache galeri internal Android 11+.
            </p>
          </div>
          <div className={`w-4 h-4 rounded-full border-2 mt-1 flex items-center justify-center ${
            selectedMode === 'MEDIASTORE_TRASH' ? 'border-cyan-400 bg-cyan-400' : 'border-slate-600'
          }`}>
            {selectedMode === 'MEDIASTORE_TRASH' && <div className="w-1.5 h-1.5 bg-slate-950 rounded-full" />}
          </div>
        </div>

        {/* Option 3: LOST.DIR & Orphans */}
        <div 
          onClick={() => onSelectMode('LOST_DIR_RECOVERY')}
          className={`p-3.5 rounded-2xl border transition cursor-pointer flex items-start gap-3.5 ${
            selectedMode === 'LOST_DIR_RECOVERY'
              ? 'bg-slate-800/90 border-cyan-500 shadow-md shadow-cyan-950/30'
              : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-800/40'
          }`}
        >
          <div className={`p-2 rounded-xl mt-0.5 ${selectedMode === 'LOST_DIR_RECOVERY' ? 'bg-cyan-500 text-slate-950' : 'bg-slate-800 text-slate-400'}`}>
            <FolderArchive className="w-4 h-4" />
          </div>
          <div className="flex-1">
            <div className="flex items-center gap-2">
              <span className="font-bold text-sm text-slate-100">LOST.DIR & Orphan Sector</span>
            </div>
            <p className="text-xs text-slate-400 mt-1 leading-relaxed">
              Memulihkan fragmen cluster tanpa ekstensi yang diselamatkan fsck setelah HP restart/mati mendadak.
            </p>
          </div>
          <div className={`w-4 h-4 rounded-full border-2 mt-1 flex items-center justify-center ${
            selectedMode === 'LOST_DIR_RECOVERY' ? 'border-cyan-400 bg-cyan-400' : 'border-slate-600'
          }`}>
            {selectedMode === 'LOST_DIR_RECOVERY' && <div className="w-1.5 h-1.5 bg-slate-950 rounded-full" />}
          </div>
        </div>
      </div>

      {/* Real Local File / Folder Carve Button */}
      <div className="pt-1">
        <input 
          ref={fileInputRef}
          type="file" 
          multiple 
          className="hidden" 
          onChange={handleFileChange}
        />
        <input 
          ref={folderInputRef}
          type="file" 
          // @ts-expect-error webkitdirectory is standard in modern browsers
          webkitdirectory=""
          directory=""
          className="hidden" 
          onChange={handleFileChange}
        />

        <div className="p-3 bg-slate-900/80 border border-dashed border-slate-700 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-slate-800 flex items-center justify-center text-cyan-400">
              <Upload className="w-4 h-4" />
            </div>
            <div>
              <p className="font-semibold text-slate-200">Uji Mesin Carving pada File / Folder Nyata</p>
              <p className="text-[11px] text-slate-400">Pilih file/dump/SD Card untuk diinspeksi binary-nya secara live</p>
            </div>
          </div>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <button
              onClick={() => fileInputRef.current?.click()}
              className="flex-1 sm:flex-initial px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg font-medium text-[11px] transition cursor-pointer"
            >
              Pilih File
            </button>
            <button
              onClick={() => folderInputRef.current?.click()}
              className="flex-1 sm:flex-initial px-3 py-1.5 bg-cyan-950 hover:bg-cyan-900 text-cyan-300 border border-cyan-800/80 rounded-lg font-medium text-[11px] transition cursor-pointer"
            >
              Pilih Folder
            </button>
          </div>
        </div>
      </div>

      {/* Main Start Deep Scan CTA */}
      <button
        onClick={onStartScan}
        className="w-full py-4 bg-gradient-to-r from-cyan-500 to-cyan-400 hover:from-cyan-400 hover:to-cyan-300 text-slate-950 font-bold rounded-2xl shadow-lg shadow-cyan-500/25 flex items-center justify-center gap-2.5 transition active:scale-[0.99] cursor-pointer"
      >
        <Search className="w-5 h-5 stroke-[2.5]" />
        <span className="text-base tracking-wide">Mulai Pemindaian Mandiri</span>
      </button>

      {/* Bottom Tool Links: Android Project Hub & Hex Lab */}
      <div className="grid grid-cols-2 gap-2.5 pt-2">
        <button
          onClick={onOpenAndroidHub}
          className="p-3 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl text-left transition flex items-center justify-between cursor-pointer group"
        >
          <div className="flex items-center gap-2">
            <FileCode2 className="w-4 h-4 text-cyan-400" />
            <div>
              <p className="text-xs font-bold text-slate-200">Project Android</p>
              <p className="text-[10px] text-slate-400">Unduh .ZIP & Source</p>
            </div>
          </div>
          <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 transition" />
        </button>

        <button
          onClick={onOpenHexLab}
          className="p-3 bg-slate-900 border border-slate-800 hover:border-slate-700 rounded-xl text-left transition flex items-center justify-between cursor-pointer group"
        >
          <div className="flex items-center gap-2">
            <Binary className="w-4 h-4 text-cyan-400" />
            <div>
              <p className="text-xs font-bold text-slate-200">Hex Forensics</p>
              <p className="text-[10px] text-slate-400">Inspeksi Signature</p>
            </div>
          </div>
          <ArrowRight className="w-3.5 h-3.5 text-slate-500 group-hover:text-cyan-400 transition" />
        </button>
      </div>
    </div>
  );
};
