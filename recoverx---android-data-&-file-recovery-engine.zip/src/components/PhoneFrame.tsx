import React, { useState, useEffect } from 'react';
import { Wifi, BatteryMedium, Signal, Smartphone, Monitor } from 'lucide-react';

interface PhoneFrameProps {
  children: React.ReactNode;
  isPhoneView: boolean;
  onToggleView: () => void;
}

export const PhoneFrame: React.FC<PhoneFrameProps> = ({ children, isPhoneView, onToggleView }) => {
  const [time, setTime] = useState('09:41');

  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      setTime(now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }));
    };
    updateTime();
    const interval = setInterval(updateTime, 30000);
    return () => clearInterval(interval);
  }, []);

  if (!isPhoneView) {
    return (
      <div className="w-full min-h-screen bg-slate-950 flex flex-col">
        {/* Top Control Bar */}
        <div className="border-b border-slate-800 bg-slate-900/80 backdrop-blur px-4 py-2 flex items-center justify-between text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <span className="inline-block w-2.5 h-2.5 rounded-full bg-cyan-500 animate-pulse" />
            <span className="font-semibold text-slate-200">RecoverX Engine Active</span>
            <span className="text-slate-600">|</span>
            <span>Android Production Mode (Kotlin / Jetpack Compose Parity)</span>
          </div>
          <button
            onClick={onToggleView}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded-lg text-xs font-medium transition cursor-pointer"
          >
            <Smartphone className="w-3.5 h-3.5 text-cyan-400" />
            <span>Tampilan Smartphone Android</span>
          </button>
        </div>
        <div className="flex-1 w-full max-w-4xl mx-auto p-4 sm:p-6 flex flex-col">
          {children}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-950 via-slate-900 to-black flex flex-col items-center justify-center p-3 sm:p-6">
      {/* View Switcher Header */}
      <div className="w-full max-w-[430px] flex items-center justify-between mb-3 text-xs text-slate-400 px-2">
        <div className="flex items-center gap-1.5 font-medium">
          <span className="w-2 h-2 rounded-full bg-cyan-400" />
          <span className="text-slate-300">Android 14 Device Bezel</span>
        </div>
        <button
          onClick={onToggleView}
          className="flex items-center gap-1.5 px-2.5 py-1 bg-slate-800/80 hover:bg-slate-700 text-slate-200 rounded-lg transition cursor-pointer text-xs"
        >
          <Monitor className="w-3.5 h-3.5 text-cyan-400" />
          <span>Tampilan Layar Penuh</span>
        </button>
      </div>

      {/* Phone Hardware Mockup */}
      <div className="relative w-full max-w-[400px] h-[830px] bg-slate-950 rounded-[48px] p-3 shadow-2xl shadow-cyan-950/40 border-[7px] border-slate-800 ring-1 ring-slate-700/50 flex flex-col overflow-hidden">
        {/* Android Punch Hole Camera */}
        <div className="absolute top-4 left-1/2 -translate-x-1/2 w-4 h-4 bg-black rounded-full z-50 ring-1 ring-slate-800/80" />

        {/* Android Status Bar */}
        <div className="h-7 w-full flex items-center justify-between px-6 text-[12px] font-semibold text-slate-300 select-none z-40 bg-slate-950/90 shrink-0">
          <span>{time}</span>
          <div className="flex items-center gap-2 text-slate-300">
            <Signal className="w-3.5 h-3.5" />
            <Wifi className="w-3.5 h-3.5" />
            <div className="flex items-center gap-0.5">
              <span className="text-[10px]">98%</span>
              <BatteryMedium className="w-4 h-4 text-emerald-400" />
            </div>
          </div>
        </div>

        {/* Screen Content Container */}
        <div className="flex-1 w-full overflow-y-auto overflow-x-hidden relative flex flex-col bg-slate-950 text-slate-100 scrollbar-none">
          {children}
        </div>

        {/* Android Gesture Bar */}
        <div className="h-5 w-full flex items-center justify-center bg-slate-950 shrink-0">
          <div className="w-32 h-1 bg-slate-600 rounded-full" />
        </div>
      </div>
    </div>
  );
};
