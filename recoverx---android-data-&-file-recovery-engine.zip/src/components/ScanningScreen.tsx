import React from 'react';
import { 
  X, Image as ImageIcon, Video, Music, FileText, Archive, Smartphone,
  Activity, Compass
} from 'lucide-react';
import { CarvedFile } from '../engine/carver';

interface ScanningScreenProps {
  currentMethod: string;
  currentPath: string;
  filesFoundCount: number;
  categoryCounts: Record<string, number>;
  onCancelScan: () => void;
}

export const ScanningScreen: React.FC<ScanningScreenProps> = ({
  currentMethod,
  currentPath,
  filesFoundCount,
  categoryCounts,
  onCancelScan
}) => {
  const categories = [
    { key: 'PHOTOS', label: 'Foto', icon: ImageIcon, color: 'text-cyan-400', count: categoryCounts['PHOTOS'] || 0 },
    { key: 'VIDEOS', label: 'Video', icon: Video, color: 'text-rose-400', count: categoryCounts['VIDEOS'] || 0 },
    { key: 'AUDIO', label: 'Audio', icon: Music, color: 'text-purple-400', count: categoryCounts['AUDIO'] || 0 },
    { key: 'DOCUMENTS', label: 'Dokumen', icon: FileText, color: 'text-blue-400', count: categoryCounts['DOCUMENTS'] || 0 },
    { key: 'ARCHIVES', label: 'Arsip ZIP', icon: Archive, color: 'text-amber-400', count: categoryCounts['ARCHIVES'] || 0 },
    { key: 'APKS', label: 'APK App', icon: Smartphone, color: 'text-emerald-400', count: categoryCounts['APKS'] || 0 },
  ];

  return (
    <div className="flex-1 flex flex-col p-4 sm:p-5 justify-between">
      {/* Top Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-ping" />
            Pemindaian Mendalam
          </h2>
          <p className="text-xs text-cyan-400 font-medium mt-0.5">{currentMethod}</p>
        </div>

        <button
          onClick={onCancelScan}
          className="flex items-center gap-1.5 px-3 py-1.5 bg-rose-950/60 hover:bg-rose-900/60 border border-rose-800/80 text-rose-300 rounded-xl text-xs font-semibold transition cursor-pointer"
        >
          <X className="w-3.5 h-3.5" />
          <span>Hentikan</span>
        </button>
      </div>

      {/* Center Radar Scanner Animation */}
      <div className="flex flex-col items-center justify-center my-6">
        <div className="relative w-44 h-44 flex items-center justify-center">
          {/* Outer Pulsing Glow */}
          <div className="absolute inset-0 rounded-full border border-cyan-500/30 bg-cyan-500/5 animate-ping opacity-30" />

          {/* Static Rings */}
          <div className="absolute inset-2 rounded-full border border-cyan-500/20" />
          <div className="absolute inset-8 rounded-full border border-cyan-500/30" />
          <div className="absolute inset-16 rounded-full border border-cyan-500/40" />

          {/* Rotating Radar Sweep */}
          <div 
            className="absolute inset-2 rounded-full origin-center animate-spin"
            style={{
              animationDuration: '3s',
              background: 'conic-gradient(from 0deg, transparent 0deg, transparent 270deg, rgba(6, 182, 212, 0.4) 360deg)'
            }}
          />

          {/* Center Sensor */}
          <div className="relative z-10 w-14 h-14 rounded-full bg-gradient-to-tr from-cyan-600 to-cyan-400 flex items-center justify-center text-slate-950 shadow-lg shadow-cyan-500/50">
            <Activity className="w-7 h-7 stroke-[2.5] animate-pulse" />
          </div>
        </div>

        {/* Big Counter */}
        <div className="text-center mt-6">
          <div className="text-4xl font-extrabold font-mono text-white tracking-tight">
            {filesFoundCount}
          </div>
          <p className="text-xs text-slate-400 mt-1">File Berhasil Diidentifikasi</p>
        </div>
      </div>

      {/* Current Path / Sector Ticker */}
      <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-3.5 shadow-sm space-y-1">
        <div className="flex items-center gap-1.5 text-[10px] font-mono text-cyan-400 font-semibold uppercase">
          <Compass className="w-3.5 h-3.5" />
          <span>Sektor yang Sedang Diperiksa</span>
        </div>
        <p className="text-xs font-mono text-slate-200 truncate">
          {currentPath || 'Memeriksa tabel alokasi kluster storage...'}
        </p>
      </div>

      {/* Category Live Counters Grid */}
      <div className="grid grid-cols-3 gap-2 mt-4">
        {categories.map((cat) => {
          const Icon = cat.icon;
          return (
            <div
              key={cat.key}
              className="bg-slate-900/80 border border-slate-800/80 rounded-xl p-2.5 flex flex-col items-center text-center"
            >
              <Icon className={`w-4 h-4 ${cat.color} mb-1`} />
              <span className="text-sm font-bold font-mono text-white">{cat.count}</span>
              <span className="text-[10px] text-slate-400 truncate w-full">{cat.label}</span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
